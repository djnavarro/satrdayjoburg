# check that you have all the packages
library(tidyverse)
library(here)
library(hexbin)
library(gganimate)
library(sf)
library(usethis)
library(scico)
library(scales)
